from resources.lib.constants import (
    ACTION_MOVIES_TRENDING,
    ACTION_MOVIES_POPULAR,
    ACTION_SEARCH_MOVIES,
)


def show(nav):
    nav.add_folder("Trending Movies", ACTION_MOVIES_TRENDING)
    nav.add_folder("Popular Movies", ACTION_MOVIES_POPULAR)
    nav.add_folder("Search Movies", ACTION_SEARCH_MOVIES, params={"input": 1})

    nav.add_folder("Continue Watching", "continue_watching")
    nav.add_folder("My Library / Lists", "library_home")
    nav.end("movies")
