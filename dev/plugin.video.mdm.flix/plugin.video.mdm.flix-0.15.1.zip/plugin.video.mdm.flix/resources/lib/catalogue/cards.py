"""Shared movie/show/episode click semantics across browse/search/home rows."""
from urllib.parse import urlencode
import xbmcgui
from resources.lib.catalogue.tmdb import TMDB, CatalogueError, number


def add_title(nav, addon, label, media, identifier, artwork=None, info=None,
              season=None, episode=None, extra_context=None):
    if media not in ("movie", "tv"):
        raise CatalogueError("Invalid title type.")
    params = {"media_type": media, "tmdb_id": number(identifier, 1)}
    is_episode = season is not None and episode is not None
    if is_episode:
        if media != "tv":
            raise CatalogueError("Invalid episode link.")
        params.update(season=number(season), episode=number(episode, 1))
    context = [("Title information", "RunPlugin(plugin://plugin.video.mdm.flix/?" +
        urlencode(dict(params, action="title_info")) + ")")]
    # Saving an episode here saves its parent show; episode progress is separate.
    from resources.lib.library_ui import command
    context.append(("My Library (show)" if is_episode else "My Library", command("library_manage", media_type=media, tmdb_id=identifier)))
    if media=='tv':context.append(('Episode controls / Intro preset',command('episode_show',tmdb_id=identifier)))
    if is_episode:
        context.append(('Intro / outro timing information',command('timing_status',tmdb_id=identifier,season=season,episode=episode)))
        query=urlencode(dict(params,action='sources',refresh='1'))
        context.append(('Refresh sources and timings','ActivateWindow(Videos,plugin://plugin.video.mdm.flix/?'+query+',return)'))
        context.append(('Timing match report',command('matching_report')))
    if media=='movie' or is_episode:
        context.append(("Viewing progress", "ActivateWindow(Videos,plugin://plugin.video.mdm.flix/?"+urlencode(dict(params,action="progress_details"))+",return)"))
    context.extend(extra_context or [])
    common = dict(params=params, artwork=artwork, info=info, context_menu=context)
    if media == "tv" and not is_episode:
        nav.add_folder(label, "tv_seasons", **common)
    elif addon.getSetting("playback_mode") == "Autoplay":
        nav.add_playable(label, "autoplay", **common)
    else:
        nav.add_folder(label, "sources", **common)


def show_info(addon, core, params):
    try:
        from resources.lib.catalogue.browse import info
        client = TMDB(addon, core)
        media = params.get("media_type", "movie")
        if media not in ("movie", "tv"):
            raise CatalogueError("Invalid title type.")
        identifier = number(params.get("tmdb_id"), 1)
        parent = None
        is_episode = "season" in params or "episode" in params
        if is_episode:
            if media != "tv":
                raise CatalogueError("Invalid episode link.")
            season = number(params.get("season")); episode = number(params.get("episode"), 1)
            parent = client.details("tv", identifier)
            data = client.request("tv/{}/season/{}/episode/{}".format(identifier, season, episode), ttl=3600)
        else:
            data = client.details(media, identifier)
        metadata = info(data, "episode" if is_episode else "movie" if media == "movie" else "tvshow", parent)
        lines = [metadata["plot"]]
        if metadata.get("premiered"):
            lines.append("Released: " + metadata["premiered"])
        if metadata.get("genre"):
            lines.append("Genres: " + ", ".join(metadata["genre"]))
        if "rating" in metadata:
            lines.append("TMDB rating: " + str(metadata["rating"]))
        if metadata.get("duration"):
            lines.append("Runtime: {} minutes".format(int(metadata["duration"] / 60)))
        lines.append("TMDB {} ID: {}".format("show" if media == "tv" else "movie", identifier))
        if is_episode:
            lines.append("Season {} · Episode {}".format(season, episode))
        xbmcgui.Dialog().textviewer(metadata["title"], "\n\n".join(lines))
    except CatalogueError as error:
        xbmcgui.Dialog().ok("MDM Flix", str(error))
    # This RunPlugin action opens only the dialog. It does not create a new
    # directory, start scraping, resolve playback or change the selected title.
