"""Per-show intro setup and deliberate next-episode navigation."""
import json
import re
import time
from datetime import date
from urllib.parse import urlencode
import xbmc
import xbmcgui
from resources.lib.playback.episode_policy import Presets,EpisodeError,timing,configuration
from resources.lib.catalogue.tmdb import TMDB,CatalogueError,number


def settings(nav,addon):
    try:
        nav.add_action('Next episode / Skip intro settings','open_settings')
        for row in Presets(addon).rows():
            nav.add_action(row['title']+(' · On' if row['enabled'] else ' · Off'),'episode_show',params={'tmdb_id':row['id']})
        nav.add_action('How show presets work','episode_help')
        nav.end('videos')
    except EpisodeError as error:xbmcgui.Dialog().ok('Episode controls',str(error));nav.end()


def setup(addon,core,params):
    try:
        if params.get('action')=='episode_help':
            xbmcgui.Dialog().ok('Episode controls','Hold/menu on a show or episode and choose Episode controls to save an intro range. At the end of an episode, choose Watch Credits to cancel the next-episode countdown. You can turn off automatic next episodes in Settings.');return
        identifier=Presets.identifier(params.get('tmdb_id'));store=Presets(addon);row=store.get(identifier)
        title=row['title'] if row else str(TMDB(addon,core).details('tv',identifier).get('name') or 'TV show')[:200]
        row=row or dict(enabled=configuration(addon)['enabled'],intro_mode='Chapters',start=0,end=0)
        selection=xbmcgui.Dialog().select(title+' · Episode controls',[
            'Turn prompts off for this show' if row['enabled'] else 'Turn prompts on for this show',
            'Use chapters (saved range as fallback)', 'Set / replace saved intro range…',
            'Use saved range for every episode', 'Turn Skip Intro off for this show',
            'Remove preset / follow new-show setting'])
        if selection<0:return
        active=row['enabled'];mode=row['intro_mode'];start=row['start'];end=row['end']
        if selection==0:active=not active
        elif selection==1:mode='Chapters';active=True
        elif selection==2:
            def ask(label,default):
                value=xbmcgui.Dialog().input(label,defaultt=str(int(default)),type=xbmcgui.INPUT_ALPHANUM)
                return None if value=='' else timing(value)
            start=ask('Intro starts: seconds or M:SS',start)
            if start is None:return
            end=ask('Intro ends: seconds or M:SS',end)
            if end is None:return
            mode='Custom';active=True
        elif selection==3:mode='Custom';active=True
        elif selection==4:mode='Off'
        elif selection==5:
            if xbmcgui.Dialog().yesno('Remove show preset?', 'This show will follow the new-shows toggle again.'):
                store.remove(identifier);xbmc.executebuiltin('Container.Refresh')
            return
        else:return
        store.save(identifier,title,active,mode,start,end)
        xbmcgui.Dialog().notification('Episode controls','Show preset saved.',xbmcgui.NOTIFICATION_INFO,3000)
        xbmc.executebuiltin('Container.Refresh')
    except (EpisodeError,CatalogueError) as error:xbmcgui.Dialog().ok('Episode controls',str(error))


def following(client,identifier,season,episode,today=None,watched=(),*,include_metadata=False):
    """TMDB episode order, including season rollover; no unannounced specials."""
    today=today or date.today().isoformat()
    all_watched=object()
    def candidates(data,season,after):
        result=[]
        for row in data['episodes']:
            if not isinstance(row,dict):continue
            try:at=number(row.get('episode_number'),1)
            except CatalogueError:continue
            if at>after:result.append((at,row))
        if not result:return None
        for at,row in sorted(result,key=lambda value:value[0]):
            released=row.get('air_date')
            if not isinstance(released,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',released) or released>today:return False
            if 'episode:{}:{}:{}'.format(identifier,season,at) not in watched:
                item = dict(media_type='episode',tmdb_id=identifier,season=season,episode=at)
                return (item, row) if include_metadata else item
        return all_watched
    result=candidates(client.season(identifier,season),season,episode)
    if result is not None and result is not all_watched:return result or None
    if season==0:return None
    details=client.details('tv',identifier)
    rows=details.get('seasons')
    if not isinstance(rows,list):raise CatalogueError('TMDB did not return the next season.')
    later=[]
    for row in rows:
        try:at=number(row.get('season_number'),1)
        except (CatalogueError,AttributeError):continue
        if at>season:later.append(at)
    # Only continue past a season if its listed episodes are all known watched.
    for next_season in sorted(set(later))[:5]:
        result=candidates(client.season(identifier,next_season),next_season,0)
        if result is not all_watched:return result or None
    return None


def wait_for_handoff(player, token):
    from resources.lib.playback.episode_controls import current_token

    monitor = xbmc.Monitor()
    deadline = time.monotonic() + 15
    quiet_since = None
    while time.monotonic() < deadline and not monitor.abortRequested():
        if player.isPlayingVideo() and current_token(player) != token:
            return False
        # Returning from fullscreen can refresh the episode directory after
        # Stop returns. Kodi 21 can abort if a second busy dialog starts then.
        busy = xbmc.getCondVisibility(
            'Container.IsUpdating | System.HasActiveModalDialog | '
            'Window.IsActive(fullscreenvideo) | Window.IsActive(busydialog) | '
            'Window.IsActive(busydialognocancel)')
        now = time.monotonic()
        if busy or player.isPlaying():
            quiet_since = None
        elif quiet_since is None:
            quiet_since = now
        elif now - quiet_since >= 1.25:
            return True
        if monitor.waitForAbort(0.1):
            return False
    if not monitor.abortRequested():
        xbmcgui.Dialog().notification('MDM Flix', 'Kodi is still busy. Open the next episode from the episode list.')
    return False


def play_next(addon,core,params):
    from resources.lib.playback import next_prompt
    from resources.lib.playback.episode_controls import current_token
    from resources.lib.playback.tracking import PROPERTY
    from resources.lib.playback.progress import clean,ProgressError
    from resources.lib.playback.viewing import Viewing
    try:
        token=params.get('token','')
        if not re.fullmatch('[0-9a-f]{32}',token):raise EpisodeError('This next-episode prompt has expired.')
        player=xbmc.Player()
        def owned():
            if current_token(player)!=token:return next_prompt.owns(player,token,params)
            raw=player.getPlayingItem().getProperty(PROPERTY)
            item=clean(json.loads(raw).get('item'))
            return item['media_type']=='episode' and all(str(item[k])==str(params.get(k)) for k in ('tmdb_id','season','episode'))
        if not owned():return
        identifier=number(params.get('tmdb_id'),1);season=number(params.get('season'));episode=number(params.get('episode'),1)
        try:
            watched=Viewing(addon).watched_keys() if addon.getSetting('progress_enabled')!='false' else ()
        except ProgressError:
            watched=()
        pending=next_prompt.read()
        target=pending.get('target') if pending and pending['token']==token else None
        next_item=(dict(media_type='episode',tmdb_id=identifier,season=number(target['season']),
                        episode=number(target['episode'],1))
                   if target and target['tmdb_id']==identifier
                   else following(TMDB(addon,core),identifier,season,episode,watched=watched))
        if not owned():return
        if not next_item:
            xbmcgui.Dialog().notification('MDM Flix','No next aired episode is available yet.',xbmcgui.NOTIFICATION_INFO,4000);return
        automatic = params.get('next_autoplay') == '1' and configuration(addon)['next_autoplay']
        action='autoplay' if automatic or addon.getSetting('playback_mode')=='Autoplay' else 'sources'
        options=dict(next_item,action=action,resume_mode='resume')
        if player.isPlayingVideo():player.stop()
        if not wait_for_handoff(player, token):return
        if automatic:
            count=number(params.get('chain_count',0),0,next_prompt.CHECK_AFTER)
            nonce=next_prompt.queue(next_item,count,params.get('unattended')=='1')
            if nonce:options['episode_chain']=nonce
        url='plugin://plugin.video.mdm.flix/?'+urlencode(options)
        if action=='autoplay':xbmc.executebuiltin('PlayMedia('+url+')')
        else:xbmc.executebuiltin('ActivateWindow(Videos,'+url+',return)')
    except (EpisodeError,CatalogueError,ProgressError,RuntimeError,ValueError,TypeError) as error:
        text=str(error) if isinstance(error,(EpisodeError,CatalogueError)) else 'The next episode could not be opened. Your current progress is kept.'
        xbmcgui.Dialog().ok('Next episode',text)
    finally:
        pending=next_prompt.read()
        if pending and pending['token']==params.get('token'):next_prompt.clear()
