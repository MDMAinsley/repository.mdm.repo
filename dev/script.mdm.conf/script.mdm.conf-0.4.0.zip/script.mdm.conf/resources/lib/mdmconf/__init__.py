"""MDM Conf configuration hub."""
__version__='0.4.0'
