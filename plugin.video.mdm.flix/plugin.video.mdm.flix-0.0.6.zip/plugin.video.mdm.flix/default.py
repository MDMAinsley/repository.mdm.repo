from resources.lib.bootstrap import run

if __name__ == "__main__":
    run()